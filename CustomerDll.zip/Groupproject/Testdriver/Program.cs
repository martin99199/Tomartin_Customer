﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GroupprojectDLL;

namespace Testdriver
{
    class Program
    {
        static void Main(string[] args)
        {
            #region positive testing valid input
            Console.WriteLine("positive testing valid input\n");
            Customer valid = new Customer("Martin", "Kogler", "martin.kogler2@students.fh-wels.at", 1);
            Console.WriteLine(valid.ToString());
            #endregion

            #region positive testing invalid input
            Customer invalid;

            Console.WriteLine("\n\npositive testing invalid input");
            Console.WriteLine("\nFirst Name is empty string");
            try
            {
                invalid = new Customer(string.Empty, "Kogler", "martin.kogler2@students.fh-wels.at", 1);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception thrown:\n" + e.Message);
            }

            Console.WriteLine("\nLast Name is empty string");
            try
            {
                invalid = new Customer("Martin", string.Empty, "martin.kogler2@students.fh-wels.at", 1);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception thrown:\n" + e.Message);
            }

            Console.WriteLine("\nE-Mail-Adress is empty string");
            try
            {
                invalid = new Customer("Martin", "Kogler", string.Empty, 1);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception thrown:\n" + e.Message);
            }

            Console.WriteLine("\nTry to change DateLastChange to an older DateTime");
            try
            {
                DateTime before = DateTime.Now;
                System.Threading.Thread.Sleep(1);
                DateTime now = DateTime.Now;
                valid.DateLastChange = now;
                valid.DateLastChange = before;
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception thrown:\n" + e.Message);
            }
            #endregion

            #region positive testing static method "ValidEMailAdress"
            Console.WriteLine("\n\npositive testing static method ValidEMailAdress");
            string validAdress = "martin.kogler@students.fh-wels.at";
            List<Customer> customerlist = new List<Customer>();
            customerlist.Add(valid);
            customerlist.Add(new Customer("Martin","Pachler","martin.pachler2@students.fh-wels.at",2));
            customerlist.Add(new Customer("Tobias","Müller","tobias.mueller2@students.fh-wels.at",3));

            Console.WriteLine("\nvalid E-Mail-Adress:\n{0}", validAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, validAdress));

            Console.WriteLine("invalid E-Mail-Adress");
            string invalidAdress = "martin.k@ogler@students.fh-wels.at";
            Console.WriteLine("\ninvalid contains more than one '@':\n{0}",invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "martin.kogler@studentsfh-welsat";
            Console.WriteLine("\ninvalid contains no dot after '@':\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "martin.kogler@students.fh-wels.a";
            Console.WriteLine("\ninvalid final part too short:\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "martin.kogler@students.fh-wels.atatat";
            Console.WriteLine("\ninvalid final part too long:\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "martin.kogler@students.fh-wels.a3t";
            Console.WriteLine("\ninvalid final part contains number:\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "martin.kogler@students.fh-wels.a$t";
            Console.WriteLine("\ninvalid final part contains special symbol:\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "@students.fh-wels.at";
            Console.WriteLine("\ninvalid no symbol before'@':\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "2@students.fh-wels.at";
            Console.WriteLine("\ninvalid only number before '@':\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "§@students.fh-wels.at";
            Console.WriteLine("\ninvalid only special symbol before '@':\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = ".martin.kogler@students.fh-wels.at";
            Console.WriteLine("\ninvalid dot at start:\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            //This case violates the lenght of final part and is therefore covered allready there
            invalidAdress = "martin.kogler@students.fh-wels.at.";
            Console.WriteLine("\ninvalid dot at end:\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "martin.kogler.@students.fh-wels.at";
            Console.WriteLine("\ninvalid dot straight before '@':\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "martin.kogler@.students.fh-wels.at";
            Console.WriteLine("\ninvalid dot straight after '@':\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            invalidAdress = "martin.ko§gler@students.fh-wels.at";
            Console.WriteLine("\ninvalid not valid symbol:\n{0}", invalidAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, invalidAdress));

            Console.WriteLine("E-Mail-Adress already exists");
            Console.WriteLine("\ninvalid Adress already exists'@':\n{0}", customerlist[0].EMailAdress);
            Console.WriteLine("result: {0}", Customer.ValidateEMailAdress(customerlist, customerlist[0].EMailAdress));
            #endregion
        }
    }
}
